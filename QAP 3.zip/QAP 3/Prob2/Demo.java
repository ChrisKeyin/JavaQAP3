public class Demo {
    public static void main(String[] args) {
        MovablePoint mp = new MovablePoint(1.1f, 2.2f, 0.5f, 0.5f);

        System.out.println("Before move: " + mp);
        mp.move();
        System.out.println("After move: " + mp);
    }
}

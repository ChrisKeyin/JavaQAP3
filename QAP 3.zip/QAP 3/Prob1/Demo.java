public class Demo {
    public static void main(String[] args) {
        Person chris = new Person("Coach Chris", 27, "M");
        System.out.println(chris);

        Student kate = new Student("Kate Hussey", 16, "F", "HS95129", 3.5);
        System.out.println(kate);

        Teacher mrjason = new Teacher("Jim Jason", 34, "M", "Computer Science", 50000);
        System.out.println(mrjason);

        CollegeStudent robert = new CollegeStudent("Robert Stark", 18, "F", "UCB123", 4.0, 1, "English");
        System.out.println(robert);
    }
}

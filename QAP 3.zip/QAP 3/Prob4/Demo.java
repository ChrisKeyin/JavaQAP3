public class Demo {
    public static void main(String[] args) {
        Shape[] shapes = new Shape[5];

        shapes[0] = new Circle("Circle1", 5);
        shapes[1] = new Ellipse("Ellipse1", 6, 4);
        shapes[2] = new Triangle("Triangle1", 3, 4, 5);
        shapes[3] = new EquilateralTriangle("Equilateral1", 6);
        shapes[4] = new Circle("Circle2", 2.5);

        System.out.println("Before scaling:");
        for (Shape s : shapes) {
            System.out.println(s);
        }

        scaleAll(shapes, 2.0f);

        System.out.println("\nAfter scaling:");
        for (Shape s : shapes) {
            System.out.println(s);
        }
    }

    public static void scaleAll(Scalable[] list, float factor) {
        for (Scalable item : list) {
            item.scale(factor);
        }
    }
}

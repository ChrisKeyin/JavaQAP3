public class Circle extends Ellipse {
    public Circle(String name, double radius) {
        super(name, radius, radius);
    }

    @Override
    public void scale(float factor) {
        a *= factor;
        b = a;
    }
}

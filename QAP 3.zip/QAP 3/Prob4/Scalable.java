public interface Scalable {
    void scale(float factor);
}

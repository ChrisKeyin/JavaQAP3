public class Circle extends Ellipse {
    public Circle(String name, double radius) {
        super(name, radius, radius);
    }
}
